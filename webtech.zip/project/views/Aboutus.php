<!DOCTYPE html>
<html>
    <head>
        <meta charset = "utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>
            ABOUT US
        </title>
        <link rel = "stylesheet" type = "text/css" href = "/project/css/about.css">
        <script src="https://kit.fontawesome.com/ec8ab4f226.js" crossorigin="anonymous"></script>
        <link rel="icon" href="img/LOGO.jpg" type="image/x-icon" >
    </head>
    <!--BODY-->
    <body>
    <div class="resta-logo">
        <a href="/project/index.php">
    <img src="img/LOGO.jpg" alt="">
</a>
    </div>
        <div class="about">
            <div class="container">
                <h1>ABOUT US</h1>

                <p>HELLO! WELCOME TO FOOD-HUB. 
                    HERE YOU CAN BUY FRESH AND GOOD QUILITY FOOD. 
                    IF YOU WANT HOME DELIVERY YOU CAN GET THIS.
                </p>

                <div class="option">
                    <a href="file:///C:/Users/Shadik%20Hasan/Desktop/WT/ABOUT%20US%20TEAM.html">OUR TEAM</a>
                </div>
                <div class="icon">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-github"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>

            </div>
        </div>



    </body>
</html>