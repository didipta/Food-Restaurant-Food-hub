<?php
function POPULARs(){
    $elemented="  
     <div class='food POPULAR'>
    <img src='img/Burgerfoodmenu.jpg'>
    <h3>Chicken Burger</h3>
    <h4>Only-230/-</h4>
    </div>

    ";
    echo $elemented;
}

?>